const contentArray = [
    "Hey Moms and Dads! Please remember to check in with your child's coach to see when and where they are playing, as well as what gear they may need. Thank you!",
    "Concussion Safety Steps: Tell an Adult: If you hit your head and feel dizzy, tired, or have a headache, tell a grown-up right away. Rest: Take a break from sports, games, and screens until you feel better. Listen to the Doctor: Only go back to playing when the doctor says it’s safe.",
    "Our guide lines: Safety First, Fair Play and Respect, Game must follow Rules,and Equal Playing Time",
    "To reach out to the Supervisor of this league please call: 724-555-1190"
  ];
  
  // Function to display content based on button index
  function showContent(index) {
    // Get the content box element
    const contentBox = document.getElementById("contentBox");
    
  
    // Update the content box with the selected content
    contentBox.textContent = contentArray[index];
  }

  